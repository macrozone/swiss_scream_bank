(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/collectionfs/tests/server-tests.js                                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
function equals(a, b) {                                                                                             // 1
  return !!(EJSON.stringify(a) === EJSON.stringify(b));                                                             // 2
}                                                                                                                   // 3
                                                                                                                    // 4
Tinytest.add('FS.Collection - server - test environment', function(test) {                                          // 5
  test.isTrue(typeof FS.Collection !== 'undefined', 'test environment not initialized FS.Collection');              // 6
  //test.isTrue(typeof CFSErrorType !== 'undefined', 'test environment not initialized CFSErrorType');              // 7
});                                                                                                                 // 8
                                                                                                                    // 9
/*                                                                                                                  // 10
 * FS.File Server Tests                                                                                             // 11
 *                                                                                                                  // 12
 * construct FS.File with no arguments                                                                              // 13
 * load data with FS.File.setDataFromBuffer                                                                         // 14
 * load data with FS.File.setDataFromBinary                                                                         // 15
 * load data and then call FS.File.toDataUrl with and without callback                                              // 16
 * load buffer into FS.File and then call FS.File.getBinary with and without start/end; make sure correct data is returned
 * construct FS.File, set FS.File.collectionName to a CFS name, and then test FS.File.update/remove/get/put/del/url // 18
 * (call these with and without callback to test sync vs. async)                                                    // 19
 * set FS.File.name to a filename and test that FS.File.getExtension() returns the extension                        // 20
 *                                                                                                                  // 21
 *                                                                                                                  // 22
 * FS.Collection Server Tests                                                                                       // 23
 *                                                                                                                  // 24
 * Make sure options.filter is respected                                                                            // 25
 *                                                                                                                  // 26
 *                                                                                                                  // 27
 */                                                                                                                 // 28
                                                                                                                    // 29
                                                                                                                    // 30
//Test API:                                                                                                         // 31
//test.isFalse(v, msg)                                                                                              // 32
//test.isTrue(v, msg)                                                                                               // 33
//test.equalactual, expected, message, not                                                                          // 34
//test.length(obj, len)                                                                                             // 35
//test.include(s, v)                                                                                                // 36
//test.isNaN(v, msg)                                                                                                // 37
//test.isUndefined(v, msg)                                                                                          // 38
//test.isNotNull                                                                                                    // 39
//test.isNull                                                                                                       // 40
//test.throws(func)                                                                                                 // 41
//test.instanceOf(obj, klass)                                                                                       // 42
//test.notEqual(actual, expected, message)                                                                          // 43
//test.runId()                                                                                                      // 44
//test.exception(exception)                                                                                         // 45
//test.expect_fail()                                                                                                // 46
//test.ok(doc)                                                                                                      // 47
//test.fail(doc)                                                                                                    // 48
//test.equal(a, b, msg)                                                                                             // 49
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
