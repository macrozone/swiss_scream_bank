(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/collectionfs/tests/client-tests.js                                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
function equals(a, b) {                                                                                             // 1
  return !!(EJSON.stringify(a) === EJSON.stringify(b));                                                             // 2
}                                                                                                                   // 3
                                                                                                                    // 4
Tinytest.add('FS.Collection - client - test environment', function(test) {                                          // 5
  test.isTrue(typeof FS.Collection !== 'undefined', 'test environment not initialized FS.Collection');              // 6
  //test.isTrue(typeof CFSErrorType !== 'undefined', 'test environment not initialized CFSErrorType');              // 7
});                                                                                                                 // 8
                                                                                                                    // 9
/*                                                                                                                  // 10
 * FS.File Client Tests                                                                                             // 11
 *                                                                                                                  // 12
 * construct FS.File with no arguments                                                                              // 13
 * construct FS.File passing in File                                                                                // 14
 * construct FS.File passing in Blob                                                                                // 15
 * load blob into FS.File and then call FS.File.toDataUrl                                                           // 16
 * call FS.File.setDataFromBinary, then FS.File.getBlob(); make sure correct data is returned                       // 17
 * load blob into FS.File and then call FS.File.getBinary() with and without start/end; make sure correct data is returned
 * construct FS.File, set FS.File.collectionName to a CFS name, and then test FS.File.update/remove/get/put/del/url // 19
 * set FS.File.name to a filename and test that FS.File.getExtension() returns the extension                        // 20
 * load blob into FS.File and make sure FS.File.saveLocal initiates a download (possibly can't do automatically)    // 21
 *                                                                                                                  // 22
 */                                                                                                                 // 23
                                                                                                                    // 24
                                                                                                                    // 25
//Test API:                                                                                                         // 26
//test.isFalse(v, msg)                                                                                              // 27
//test.isTrue(v, msg)                                                                                               // 28
//test.equalactual, expected, message, not                                                                          // 29
//test.length(obj, len)                                                                                             // 30
//test.include(s, v)                                                                                                // 31
//test.isNaN(v, msg)                                                                                                // 32
//test.isUndefined(v, msg)                                                                                          // 33
//test.isNotNull                                                                                                    // 34
//test.isNull                                                                                                       // 35
//test.throws(func)                                                                                                 // 36
//test.instanceOf(obj, klass)                                                                                       // 37
//test.notEqual(actual, expected, message)                                                                          // 38
//test.runId()                                                                                                      // 39
//test.exception(exception)                                                                                         // 40
//test.expect_fail()                                                                                                // 41
//test.ok(doc)                                                                                                      // 42
//test.fail(doc)                                                                                                    // 43
//test.equal(a, b, msg)                                                                                             // 44
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
